export interface Login {
    id_login?: number
    email: string
    senha?: string
    perfil?: string
}